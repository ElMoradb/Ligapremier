<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/menusito', 'menu::menusito');


$routes->get('/canchas','Canchas::index');
$routes->get('/arbitros','Arbitro::index');

$routes->get('/canchas/add','Canchas::add');
$routes->get('/arbitros/add','Arbitro::add');

$routes->post('/canchas/insert','Canchas::insert');
$routes->post('/arbitros/insert','Arbitro::insert');

$routes->get('/canchas/edit/(:num)','Canchas::edit/$1');
$routes->get('/arbitros/edit/(:num)','Arbitro::edit/$1');

$routes->post('/canchas/update/','Canchas::update/');
$routes->post('/arbitros/update/','Arbitro::update/');

$routes->get('/canchas/delete/(:num)','Canchas::delete/$1');
$routes->get('/arbitros/delete/(:num)','Arbitro::delete/$1');


